---
tags: MIUI12开发板
abbrlink: 57380
date: 2020-06-28 17:30:10
---
| Redmi K30  开发版/内测版    |
| ---- |
<!-- more -->
| [miui_PHOENIX_20.6.23_9bde4842b2_10.0.zip](https://hugeota.d.miui.com/20.6.23/miui_PHOENIX_20.6.23_9bde4842b2_10.0.zip)    |
| [miui_PHOENIX_20.6.18_c830f7e430_10.0.zip](https://hugeota.d.miui.com/20.6.18/miui_PHOENIX_20.6.18_c830f7e430_10.0.zip)    |
| [miui_PHOENIX_20.6.17_dc76187aba_10.0.zip](https://hugeota.d.miui.com/20.6.17/miui_PHOENIX_20.6.17_dc76187aba_10.0.zip)    |
| [miui_PHOENIX_20.6.16_cadb8a6eed_10.0.zip](https://hugeota.d.miui.com/20.6.16/miui_PHOENIX_20.6.16_cadb8a6eed_10.0.zip)    |
| [miui_PHOENIX_20.6.15_257810f39d_10.0.zip](https://hugeota.d.miui.com/20.6.15/miui_PHOENIX_20.6.15_257810f39d_10.0.zip)    |
| [miui_PHOENIX_20.6.11_1c6628de30_10.0.zip](https://hugeota.d.miui.com/20.6.11/miui_PHOENIX_20.6.11_1c6628de30_10.0.zip)    |
| [miui_PHOENIX_20.6.10_c2a0d8563d_10.0.zip](https://hugeota.d.miui.com/20.6.10/miui_PHOENIX_20.6.10_c2a0d8563d_10.0.zip)    |
| [miui_PHOENIX_20.6.8_f6825a0285_10.0.zip](https://hugeota.d.miui.com/20.6.8/miui_PHOENIX_20.6.8_f6825a0285_10.0.zip)    |
| [miui_PHOENIX_20.6.4_9612d32a97_10.0.zip](https://hugeota.d.miui.com/20.6.4/miui_PHOENIX_20.6.4_9612d32a97_10.0.zip)    |
| [miui_PHOENIX_20.6.3_d6302dfec9_10.0.zip](https://hugeota.d.miui.com/20.6.3/miui_PHOENIX_20.6.3_d6302dfec9_10.0.zip)    |
| [miui_PHOENIX_20.6.2_5916f1685b_10.0.zip](https://hugeota.d.miui.com/20.6.2/miui_PHOENIX_20.6.2_5916f1685b_10.0.zip)    |
| [miui_PHOENIX_20.6.1_d1fe9912be_10.0.zip](https://hugeota.d.miui.com/20.6.1/miui_PHOENIX_20.6.1_d1fe9912be_10.0.zip)    |
| [miui_PHOENIX_20.5.28_ef1f0d470e_10.0.zip](https://hugeota.d.miui.com/20.5.28/miui_PHOENIX_20.5.28_ef1f0d470e_10.0.zip)    |
| [miui_PHOENIX_20.5.26_072e077ccd_10.0.zip](https://hugeota.d.miui.com/20.5.26/miui_PHOENIX_20.5.26_072e077ccd_10.0.zip)    |
| [miui_PHOENIX_20.5.25_82a3165287_10.0.zip](https://hugeota.d.miui.com/20.5.25/miui_PHOENIX_20.5.25_82a3165287_10.0.zip)    |
| [miui_PHOENIX_20.5.21_1912be2069_10.0.zip](https://hugeota.d.miui.com/20.5.21/miui_PHOENIX_20.5.21_1912be2069_10.0.zip)    |
| [miui_PHOENIX_20.5.20_31b4a043c1_10.0.zip](https://hugeota.d.miui.com/20.5.20/miui_PHOENIX_20.5.20_31b4a043c1_10.0.zip)    |
| [miui_PHOENIX_20.5.19_58f88ac097_10.0.zip](https://hugeota.d.miui.com/20.5.19/miui_PHOENIX_20.5.19_58f88ac097_10.0.zip)    |
| [miui_PHOENIX_20.5.18_534bba071e_10.0.zip](https://hugeota.d.miui.com/20.5.18/miui_PHOENIX_20.5.18_534bba071e_10.0.zip)    |
| [miui_PHOENIX_20.5.14_fcd2062c3b_10.0.zip](https://hugeota.d.miui.com/20.5.14/miui_PHOENIX_20.5.14_fcd2062c3b_10.0.zip)    |
| [miui_PHOENIX_20.5.13_f487ce9a89_10.0.zip](https://hugeota.d.miui.com/20.5.13/miui_PHOENIX_20.5.13_f487ce9a89_10.0.zip)    |
| [miui_PHOENIX_20.5.12_8a537771fd_10.0.zip](https://hugeota.d.miui.com/20.5.12/miui_PHOENIX_20.5.12_8a537771fd_10.0.zip)    |
| [miui_PHOENIX_20.5.11_af51f5bfc1_10.0.zip](https://hugeota.d.miui.com/20.5.11/miui_PHOENIX_20.5.11_af51f5bfc1_10.0.zip)    |
| [miui_PHOENIX_20.5.6_792dfb6f8f_10.0.zip](https://hugeota.d.miui.com/20.5.6/miui_PHOENIX_20.5.6_792dfb6f8f_10.0.zip)    |
| [miui_PHOENIX_20.4.30_b464c790c0_10.0.zip](https://hugeota.d.miui.com/20.4.30/miui_PHOENIX_20.4.30_b464c790c0_10.0.zip)    |
| [miui_PHOENIX_20.4.28_a04a06f359_10.0.zip](https://hugeota.d.miui.com/20.4.28/miui_PHOENIX_20.4.28_a04a06f359_10.0.zip)    |
| [miui_PHOENIX_20.4.27_bce2a50650_10.0.zip](https://hugeota.d.miui.com/20.4.27/miui_PHOENIX_20.4.27_bce2a50650_10.0.zip)    |
| [miui_PHOENIX_20.3.26_435eaaa7de_10.0.zip](https://hugeota.d.miui.com/20.3.26/miui_PHOENIX_20.3.26_435eaaa7de_10.0.zip)    |
| [miui_PHOENIX_20.3.25_991a8cdbb7_10.0.zip](https://hugeota.d.miui.com/20.3.25/miui_PHOENIX_20.3.25_991a8cdbb7_10.0.zip)    |
| [miui_PHOENIX_20.3.24_ce806a080e_10.0.zip](https://hugeota.d.miui.com/20.3.24/miui_PHOENIX_20.3.24_ce806a080e_10.0.zip)    |
| [miui_PHOENIX_20.3.23_e0b792a7f3_10.0.zip](https://hugeota.d.miui.com/20.3.23/miui_PHOENIX_20.3.23_e0b792a7f3_10.0.zip)    |
| [miui_PHOENIX_20.3.19_0b64fcf9af_10.0.zip](https://hugeota.d.miui.com/20.3.19/miui_PHOENIX_20.3.19_0b64fcf9af_10.0.zip)    |
| [miui_PHOENIX_20.3.18_27ede27cde_10.0.zip](https://hugeota.d.miui.com/20.3.18/miui_PHOENIX_20.3.18_27ede27cde_10.0.zip)    |
| [miui_PHOENIX_20.3.17_3f9d8399cb_10.0.zip](https://hugeota.d.miui.com/20.3.17/miui_PHOENIX_20.3.17_3f9d8399cb_10.0.zip)    |
| [miui_PHOENIX_20.3.16_ec308e4ea1_10.0.zip](https://hugeota.d.miui.com/20.3.16/miui_PHOENIX_20.3.16_ec308e4ea1_10.0.zip)    |
| [miui_PHOENIX_20.3.12_92ce6d32bd_10.0.zip](https://hugeota.d.miui.com/20.3.12/miui_PHOENIX_20.3.12_92ce6d32bd_10.0.zip)    |
| [miui_PHOENIX_20.3.11_40fb4a33ac_10.0.zip](https://hugeota.d.miui.com/20.3.11/miui_PHOENIX_20.3.11_40fb4a33ac_10.0.zip)    |
| [miui_PHOENIX_20.3.5_e6b985bc51_10.0.zip](https://hugeota.d.miui.com/20.3.5/miui_PHOENIX_20.3.5_e6b985bc51_10.0.zip)    |
| [miui_PHOENIX_20.3.4_3eecb52d1d_10.0.zip](https://hugeota.d.miui.com/20.3.4/miui_PHOENIX_20.3.4_3eecb52d1d_10.0.zip)    |
| [miui_PHOENIX_20.3.3_13a5349122_10.0.zip](https://hugeota.d.miui.com/20.3.3/miui_PHOENIX_20.3.3_13a5349122_10.0.zip)    |
| [miui_PHOENIX_20.2.25_51803a8cbc_10.0.zip](https://hugeota.d.miui.com/20.2.25/miui_PHOENIX_20.2.25_51803a8cbc_10.0.zip)    |
| [miui_PHOENIX_20.2.20_210f81bb20_10.0.zip](https://hugeota.d.miui.com/20.2.20/miui_PHOENIX_20.2.20_210f81bb20_10.0.zip)    |
| [miui_PHOENIX_20.2.19_da7c8b08e8_10.0.zip](https://hugeota.d.miui.com/20.2.19/miui_PHOENIX_20.2.19_da7c8b08e8_10.0.zip)    |
| [miui_PHOENIX_20.2.18_fd5e4a0b8e_10.0.zip](https://hugeota.d.miui.com/20.2.18/miui_PHOENIX_20.2.18_fd5e4a0b8e_10.0.zip)    |
| [miui_PHOENIX_20.2.17_e89d22c684_10.0.zip](https://hugeota.d.miui.com/20.2.17/miui_PHOENIX_20.2.17_e89d22c684_10.0.zip)    |
| [miui_PHOENIX_20.1.21_724ef91eca_10.0.zip](https://hugeota.d.miui.com/20.1.21/miui_PHOENIX_20.1.21_724ef91eca_10.0.zip)    |
| [miui_PHOENIX_20.1.16_46d37d72db_10.0.zip](https://hugeota.d.miui.com/20.1.16/miui_PHOENIX_20.1.16_46d37d72db_10.0.zip)    |
| [miui_PHOENIX_20.1.13_70f361a40b_10.0.zip](https://hugeota.d.miui.com/20.1.13/miui_PHOENIX_20.1.13_70f361a40b_10.0.zip)    |
| [miui_PHOENIX_20.1.8_6527f50cce_10.0.zip](https://hugeota.d.miui.com/20.1.8/miui_PHOENIX_20.1.8_6527f50cce_10.0.zip)    |
