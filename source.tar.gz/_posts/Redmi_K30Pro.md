---
tags: MIUI12开发板
abbrlink: 22125
date: 2020-06-28 17:30:10
---
| Redmi K30Pro  开发版/内测版    |
| ---- |
<!-- more -->
| [miui_LMI_20.5.24_80680c42ee_10.0.zip](https://hugeota.d.miui.com/20.5.24/miui_LMI_20.5.24_80680c42ee_10.0.zip)    |
| [miui_LMI_20.5.22_aaa07fd268_10.0.zip](https://hugeota.d.miui.com/20.5.22/miui_LMI_20.5.22_aaa07fd268_10.0.zip)    |
| [miui_LMI_20.5.21_b64a295251_10.0.zip](https://hugeota.d.miui.com/20.5.21/miui_LMI_20.5.21_b64a295251_10.0.zip)    |
| [miui_LMI_20.5.20_e0bb0e65a4_10.0.zip](https://hugeota.d.miui.com/20.5.20/miui_LMI_20.5.20_e0bb0e65a4_10.0.zip)    |
| [miui_LMI_20.5.7_b9f4ded3cd_10.0.zip](https://hugeota.d.miui.com/20.5.7/miui_LMI_20.5.7_b9f4ded3cd_10.0.zip)    |
