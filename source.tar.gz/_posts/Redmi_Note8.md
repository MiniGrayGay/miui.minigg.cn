---
tags: MIUI12开发板
abbrlink: 20398
date: 2020-06-28 17:30:10
---
| Redmi Note8  开发版/内测版    |
| ---- |
<!-- more -->
| [miui_GINKGO_20.6.17_50f25d9985_10.0.zip](https://hugeota.d.miui.com/20.6.17/miui_GINKGO_20.6.17_50f25d9985_10.0.zip)    |
| [miui_GINKGO_20.3.26_45c815e2bf_9.0.zip](https://hugeota.d.miui.com/20.3.26/miui_GINKGO_20.3.26_45c815e2bf_9.0.zip)    |
| [miui_GINKGO_20.3.25_3de8dd6db0_9.0.zip](https://hugeota.d.miui.com/20.3.25/miui_GINKGO_20.3.25_3de8dd6db0_9.0.zip)    |
| [miui_GINKGO_20.3.18_3bb022bebc_9.0.zip](https://hugeota.d.miui.com/20.3.18/miui_GINKGO_20.3.18_3bb022bebc_9.0.zip)    |
| [miui_GINKGO_20.3.17_b35a73549d_9.0.zip](https://hugeota.d.miui.com/20.3.17/miui_GINKGO_20.3.17_b35a73549d_9.0.zip)    |
| [miui_GINKGO_20.3.16_459c6f381a_9.0.zip](https://hugeota.d.miui.com/20.3.16/miui_GINKGO_20.3.16_459c6f381a_9.0.zip)    |
| [miui_GINKGO_20.3.12_b68a15e0c2_9.0.zip](https://hugeota.d.miui.com/20.3.12/miui_GINKGO_20.3.12_b68a15e0c2_9.0.zip)    |
| [miui_GINKGO_20.3.11_21f39c6e83_9.0.zip](https://hugeota.d.miui.com/20.3.11/miui_GINKGO_20.3.11_21f39c6e83_9.0.zip)    |
| [miui_GINKGO_20.3.10_1a3d3dc8e3_9.0.zip](https://hugeota.d.miui.com/20.3.10/miui_GINKGO_20.3.10_1a3d3dc8e3_9.0.zip)    |
| [miui_GINKGO_20.3.9_1b595c8009_9.0.zip](https://hugeota.d.miui.com/20.3.9/miui_GINKGO_20.3.9_1b595c8009_9.0.zip)    |
| [miui_GINKGO_20.3.5_bb2dcc1530_9.0.zip](https://hugeota.d.miui.com/20.3.5/miui_GINKGO_20.3.5_bb2dcc1530_9.0.zip)    |
| [miui_GINKGO_20.3.4_fa9094f7c4_9.0.zip](https://hugeota.d.miui.com/20.3.4/miui_GINKGO_20.3.4_fa9094f7c4_9.0.zip)    |
| [miui_GINKGO_20.3.3_5594ebe80b_9.0.zip](https://hugeota.d.miui.com/20.3.3/miui_GINKGO_20.3.3_5594ebe80b_9.0.zip)    |
| [miui_GINKGO_20.3.2_10f9c8fbff_9.0.zip](https://hugeota.d.miui.com/20.3.2/miui_GINKGO_20.3.2_10f9c8fbff_9.0.zip)    |
| [miui_GINKGO_20.2.27_1c30fddd73_9.0.zip](https://hugeota.d.miui.com/20.2.27/miui_GINKGO_20.2.27_1c30fddd73_9.0.zip)    |
| [miui_GINKGO_20.2.26_1a7b7a78bd_9.0.zip](https://hugeota.d.miui.com/20.2.26/miui_GINKGO_20.2.26_1a7b7a78bd_9.0.zip)    |
| [miui_GINKGO_20.2.25_1e06541c57_9.0.zip](https://hugeota.d.miui.com/20.2.25/miui_GINKGO_20.2.25_1e06541c57_9.0.zip)    |
| [miui_GINKGO_20.1.16_1b7294bdbb_9.0.zip](https://hugeota.d.miui.com/20.1.16/miui_GINKGO_20.1.16_1b7294bdbb_9.0.zip)    |
| [miui_GINKGO_20.1.15_8991f3c44f_9.0.zip](https://hugeota.d.miui.com/20.1.15/miui_GINKGO_20.1.15_8991f3c44f_9.0.zip)    |
| [miui_GINKGO_20.1.14_819bdf90dd_9.0.zip](https://hugeota.d.miui.com/20.1.14/miui_GINKGO_20.1.14_819bdf90dd_9.0.zip)    |
| [miui_GINKGO_20.1.13_68fbdf746a_9.0.zip](https://hugeota.d.miui.com/20.1.13/miui_GINKGO_20.1.13_68fbdf746a_9.0.zip)    |
| [miui_GINKGO_20.1.9_762f051143_9.0.zip](https://hugeota.d.miui.com/20.1.9/miui_GINKGO_20.1.9_762f051143_9.0.zip)    |
| [miui_GINKGO_20.1.8_45b34b89fe_9.0.zip](https://hugeota.d.miui.com/20.1.8/miui_GINKGO_20.1.8_45b34b89fe_9.0.zip)    |
| [miui_GINKGO_20.1.7_bdfb2ff8bb_9.0.zip](https://hugeota.d.miui.com/20.1.7/miui_GINKGO_20.1.7_bdfb2ff8bb_9.0.zip)    |
| [miui_GINKGO_20.1.3_c262a882cc_9.0.zip](https://hugeota.d.miui.com/20.1.3/miui_GINKGO_20.1.3_c262a882cc_9.0.zip)    |
| [miui_GINKGO_20.1.2_55eef1616e_9.0.zip](https://hugeota.d.miui.com/20.1.2/miui_GINKGO_20.1.2_55eef1616e_9.0.zip)    |
