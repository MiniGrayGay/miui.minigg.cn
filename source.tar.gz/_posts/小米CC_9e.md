---
tags: MIUI12开发板
abbrlink: 43559
date: 2020-06-28 17:30:10
---
| 小米CC 9e  开发版/内测版    |
| ---- |
<!-- more -->
| [miui_LAURUS_20.6.23_2f7e303d03_10.0.zip](https://hugeota.d.miui.com/20.6.23/miui_LAURUS_20.6.23_2f7e303d03_10.0.zip)    |
| [miui_LAURUS_20.6.15_81fc042923_10.0.zip](https://hugeota.d.miui.com/20.6.15/miui_LAURUS_20.6.15_81fc042923_10.0.zip)    |
| [miui_LAURUS_20.6.10_967022bf94_10.0.zip](https://hugeota.d.miui.com/20.6.10/miui_LAURUS_20.6.10_967022bf94_10.0.zip)    |
| [miui_LAURUS_20.3.10_1439f61890_9.0.zip](https://hugeota.d.miui.com/20.3.10/miui_LAURUS_20.3.10_1439f61890_9.0.zip)    |
| [miui_LAURUS_20.2.25_90b60c416f_9.0.zip](https://hugeota.d.miui.com/20.2.25/miui_LAURUS_20.2.25_90b60c416f_9.0.zip)    |
| [miui_LAURUS_20.1.16_77850857d0_9.0.zip](https://hugeota.d.miui.com/20.1.16/miui_LAURUS_20.1.16_77850857d0_9.0.zip)    |
| [miui_LAURUS_20.1.15_bf75691f8c_9.0.zip](https://hugeota.d.miui.com/20.1.15/miui_LAURUS_20.1.15_bf75691f8c_9.0.zip)    |
