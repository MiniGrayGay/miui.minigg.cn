---
tags: MIUI12开发板
abbrlink: 46899
date: 2020-06-28 17:30:10
---
| Redmi Note7 Pro  开发版/内测版    |
| ---- |
<!-- more -->
| [miui_VIOLET_20.6.23_b9d6b84942_10.0.zip](https://hugeota.d.miui.com/20.6.23/miui_VIOLET_20.6.23_b9d6b84942_10.0.zip)    |
| [miui_VIOLET_20.6.18_478cbb7a95_10.0.zip](https://hugeota.d.miui.com/20.6.18/miui_VIOLET_20.6.18_478cbb7a95_10.0.zip)    |
| [miui_VIOLET_20.6.17_72bd874f28_10.0.zip](https://hugeota.d.miui.com/20.6.17/miui_VIOLET_20.6.17_72bd874f28_10.0.zip)    |
| [miui_VIOLET_20.6.16_06ee33409e_10.0.zip](https://hugeota.d.miui.com/20.6.16/miui_VIOLET_20.6.16_06ee33409e_10.0.zip)    |
| [miui_VIOLET_20.6.15_e823f20777_10.0.zip](https://hugeota.d.miui.com/20.6.15/miui_VIOLET_20.6.15_e823f20777_10.0.zip)    |
| [miui_VIOLET_20.6.11_38335677af_10.0.zip](https://hugeota.d.miui.com/20.6.11/miui_VIOLET_20.6.11_38335677af_10.0.zip)    |
| [miui_VIOLET_20.6.10_34a967ce6a_10.0.zip](https://hugeota.d.miui.com/20.6.10/miui_VIOLET_20.6.10_34a967ce6a_10.0.zip)    |
| [miui_VIOLET_20.6.8_0b9f79417f_10.0.zip](https://hugeota.d.miui.com/20.6.8/miui_VIOLET_20.6.8_0b9f79417f_10.0.zip)    |
| [miui_VIOLET_20.6.4_4ceb3ce2e8_10.0.zip](https://hugeota.d.miui.com/20.6.4/miui_VIOLET_20.6.4_4ceb3ce2e8_10.0.zip)    |
| [miui_VIOLET_20.6.3_8d65d9b1b1_10.0.zip](https://hugeota.d.miui.com/20.6.3/miui_VIOLET_20.6.3_8d65d9b1b1_10.0.zip)    |
| [miui_VIOLET_20.6.2_9a51f4e0bb_10.0.zip](https://hugeota.d.miui.com/20.6.2/miui_VIOLET_20.6.2_9a51f4e0bb_10.0.zip)    |
| [miui_VIOLET_20.6.1_68c5f851ce_10.0.zip](https://hugeota.d.miui.com/20.6.1/miui_VIOLET_20.6.1_68c5f851ce_10.0.zip)    |
| [miui_VIOLET_20.5.29_5f9260a9f1_10.0.zip](https://hugeota.d.miui.com/20.5.29/miui_VIOLET_20.5.29_5f9260a9f1_10.0.zip)    |
| [miui_VIOLET_20.5.28_c814552457_10.0.zip](https://hugeota.d.miui.com/20.5.28/miui_VIOLET_20.5.28_c814552457_10.0.zip)    |
| [miui_VIOLET_20.5.26_803d9171ac_10.0.zip](https://hugeota.d.miui.com/20.5.26/miui_VIOLET_20.5.26_803d9171ac_10.0.zip)    |
| [miui_VIOLET_20.5.25_12640b92e3_10.0.zip](https://hugeota.d.miui.com/20.5.25/miui_VIOLET_20.5.25_12640b92e3_10.0.zip)    |
| [miui_VIOLET_20.5.21_dc89619adc_10.0.zip](https://hugeota.d.miui.com/20.5.21/miui_VIOLET_20.5.21_dc89619adc_10.0.zip)    |
| [miui_VIOLET_20.5.20_1656672189_10.0.zip](https://hugeota.d.miui.com/20.5.20/miui_VIOLET_20.5.20_1656672189_10.0.zip)    |
| [miui_VIOLET_20.5.19_0945e4606a_10.0.zip](https://hugeota.d.miui.com/20.5.19/miui_VIOLET_20.5.19_0945e4606a_10.0.zip)    |
| [miui_VIOLET_20.5.13_f85f51349e_10.0.zip](https://hugeota.d.miui.com/20.5.13/miui_VIOLET_20.5.13_f85f51349e_10.0.zip)    |
| [miui_VIOLET_20.5.12_d5db66d565_10.0.zip](https://hugeota.d.miui.com/20.5.12/miui_VIOLET_20.5.12_d5db66d565_10.0.zip)    |
| [miui_VIOLET_20.5.11_ff799af26b_10.0.zip](https://hugeota.d.miui.com/20.5.11/miui_VIOLET_20.5.11_ff799af26b_10.0.zip)    |
| [miui_VIOLET_20.5.6_c0d4b0e09c_10.0.zip](https://hugeota.d.miui.com/20.5.6/miui_VIOLET_20.5.6_c0d4b0e09c_10.0.zip)    |
| [miui_VIOLET_20.4.30_0a72a359e3_10.0.zip](https://hugeota.d.miui.com/20.4.30/miui_VIOLET_20.4.30_0a72a359e3_10.0.zip)    |
| [miui_VIOLET_20.4.28_cbe35aec33_10.0.zip](https://hugeota.d.miui.com/20.4.28/miui_VIOLET_20.4.28_cbe35aec33_10.0.zip)    |
| [miui_VIOLET_20.4.27_172d429ff5_10.0.zip](https://hugeota.d.miui.com/20.4.27/miui_VIOLET_20.4.27_172d429ff5_10.0.zip)    |
| [miui_VIOLET_20.3.26_3a91bbe202_10.0.zip](https://hugeota.d.miui.com/20.3.26/miui_VIOLET_20.3.26_3a91bbe202_10.0.zip)    |
| [miui_VIOLET_20.3.25_896b7624bb_10.0.zip](https://hugeota.d.miui.com/20.3.25/miui_VIOLET_20.3.25_896b7624bb_10.0.zip)    |
| [miui_VIOLET_20.3.24_ed711bd7ad_10.0.zip](https://hugeota.d.miui.com/20.3.24/miui_VIOLET_20.3.24_ed711bd7ad_10.0.zip)    |
| [miui_VIOLET_20.3.23_f559a47b5b_10.0.zip](https://hugeota.d.miui.com/20.3.23/miui_VIOLET_20.3.23_f559a47b5b_10.0.zip)    |
| [miui_VIOLET_20.3.19_2d772673b8_10.0.zip](https://hugeota.d.miui.com/20.3.19/miui_VIOLET_20.3.19_2d772673b8_10.0.zip)    |
| [miui_VIOLET_20.3.17_735f731e35_10.0.zip](https://hugeota.d.miui.com/20.3.17/miui_VIOLET_20.3.17_735f731e35_10.0.zip)    |
| [miui_VIOLET_20.3.16_e8efa875ec_10.0.zip](https://hugeota.d.miui.com/20.3.16/miui_VIOLET_20.3.16_e8efa875ec_10.0.zip)    |
| [miui_VIOLET_20.3.12_5949f150d4_10.0.zip](https://hugeota.d.miui.com/20.3.12/miui_VIOLET_20.3.12_5949f150d4_10.0.zip)    |
| [miui_VIOLET_20.3.11_280340fcc0_10.0.zip](https://hugeota.d.miui.com/20.3.11/miui_VIOLET_20.3.11_280340fcc0_10.0.zip)    |
| [miui_VIOLET_20.3.5_5225b86870_10.0.zip](https://hugeota.d.miui.com/20.3.5/miui_VIOLET_20.3.5_5225b86870_10.0.zip)    |
| [miui_VIOLET_20.3.4_472252b640_10.0.zip](https://hugeota.d.miui.com/20.3.4/miui_VIOLET_20.3.4_472252b640_10.0.zip)    |
| [miui_VIOLET_9.11.7_d05fe890bd_9.0.zip](https://hugeota.d.miui.com/9.11.7/miui_VIOLET_9.11.7_d05fe890bd_9.0.zip)    |
| [miui_VIOLET_9.10.24_e5cadaab87_9.0.zip](https://hugeota.d.miui.com/9.10.24/miui_VIOLET_9.10.24_e5cadaab87_9.0.zip)    |
| [miui_VIOLET_9.10.10_d082faf7f0_9.0.zip](https://hugeota.d.miui.com/9.10.10/miui_VIOLET_9.10.10_d082faf7f0_9.0.zip)    |
| [miui_VIOLET_9.10.8_3922aeecc4_9.0.zip](https://hugeota.d.miui.com/9.10.8/miui_VIOLET_9.10.8_3922aeecc4_9.0.zip)    |
| [miui_VIOLET_9.8.22_bdf4f2d7c1_9.0.zip](https://hugeota.d.miui.com/9.8.22/miui_VIOLET_9.8.22_bdf4f2d7c1_9.0.zip)    |
| [miui_VIOLET_9.8.15_e8055d326d_9.0.zip](https://hugeota.d.miui.com/9.8.15/miui_VIOLET_9.8.15_e8055d326d_9.0.zip)    |
| [miui_VIOLET_9.8.9_601e2c82fb_9.0.zip](https://hugeota.d.miui.com/9.8.9/miui_VIOLET_9.8.9_601e2c82fb_9.0.zip)    |
| [miui_VIOLET_9.8.1_08f4d6c279_9.0.zip](https://hugeota.d.miui.com/9.8.1/miui_VIOLET_9.8.1_08f4d6c279_9.0.zip)    |
| [miui_VIOLET_9.7.25_b784f59c29_9.0.zip](https://hugeota.d.miui.com/9.7.25/miui_VIOLET_9.7.25_b784f59c29_9.0.zip)    |
